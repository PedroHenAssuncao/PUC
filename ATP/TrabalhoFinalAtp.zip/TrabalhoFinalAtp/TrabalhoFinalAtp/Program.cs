﻿// See https://aka.ms/new-console-template for more information
using TrabalhoFinalAtp;

Console.WriteLine("Trabalho de Pedro Henrique Assunção");


InteracaoUsuario.MenuUsuario();